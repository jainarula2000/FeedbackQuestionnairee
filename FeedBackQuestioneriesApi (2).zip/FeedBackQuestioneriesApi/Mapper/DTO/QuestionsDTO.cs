using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Models.Entity;

namespace FeebackQuestionaireAPI.Mapper.DTO
{
    public class QuestionsDTO
    {
          public int QuesId{get;set;}  
          public string QuestionName{get;set;}
          public int FormId{get;set;}
          public int TypeId{get;set;}
       // public IList<OptionsDTO> Options { get; set; }
        //  public virtual QuestionTypes Questiontypes{get;set;}

    }
}