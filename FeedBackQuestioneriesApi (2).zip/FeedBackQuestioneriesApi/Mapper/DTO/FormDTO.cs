using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using FeedBackQuestioneriesApi.Mapper.DTO;
using static FeebackQuestionaireAPI.Models.Entity.Form;

public class FormDtO
    {
        
        public string Title { get; set; }
        public string Description { get; set; }
        public string Link { get; set; }
        public int Submissions { get; set; }
        public DateTime PublishedDate { get; set; }
        public Status Status { get; set; }
        public DateTime ClosedDate { get; set; }
        public bool IsDeleted{get;set;}
    }

    //     public IList<Question>Questions{get;set;}
    //     public IList<MutipleChoice> mutipleChoices{ get; set; }
    //     public IList<singleoptionsQuestion> singleoptionsQuestions { get; set; }
    //     public IList<RatingQuestion> ratingQuestions { get; set; }
    //     public IList<RankingQuestion> rankingQuestions { get; set; }
    //     public IList<SingleLineQuestion> singleLineQuestion { get; set; }
    //     public IList<MultiLineQuestion> multiLineQuestions { get; set; }
        
    // }

    // public class RatingQuestion:QuesTypeDTO
    // {
       
    // }
    // public class RankingQuestion:QuesTypeDTO
    // {
        
    // }

    // public class SingleLineQuestion:QuesTypeDTO
    // {
        
    // }
    // public class singleoptionsQuestion:QuesTypeDTO
    // {
    //     public string radio1 { get; set; }
    //     public string radio2 { get; set; }
    //     public string radio3 { get; set; }
    //     public string radio4 { get; set; }
    // }
    // public class MultiLineQuestion:QuesTypeDTO
    // {
    // }
    // public class MutipleChoice:QuesTypeDTO
    // {
    //     public string checkbox1 { get; set; }
    //     public string checkbox2 { get; set; }
    //     public string checkbox3 { get; set; }
    //     public string checkbox4 { get; set; }
    // }
