using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FeebackQuestionaireAPI.Mapper.DTO
{
    public class OptionsDTO
    {
        public int OptionId{get;set;}
         public int QuestId{get;set;}
        public string Option{get;set;}
        public virtual QuestionsDTO QuestionsDTO{get;set;}
    }
}