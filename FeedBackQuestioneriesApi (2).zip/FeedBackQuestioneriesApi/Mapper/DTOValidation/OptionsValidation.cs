using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;
using FluentValidation;

namespace FeebackQuestionaireAPI.Mapper.DTOValidation
{
    public class OptionsValidation:AbstractValidator<OptionsDTO>
    {
        public OptionsValidation()
        {
            RuleFor(OptionsDTO => OptionsDTO.Option).NotEmpty();
            

        }
    }
   
}