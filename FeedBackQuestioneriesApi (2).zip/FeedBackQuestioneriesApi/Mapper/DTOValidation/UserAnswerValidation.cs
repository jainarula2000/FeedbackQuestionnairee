using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;
using FluentValidation;

namespace FeebackQuestionaireAPI.Mapper.DTOValidation
{
    public class UserAnswerValidation : AbstractValidator<UserAnswerDto>
    {
        public UserAnswerValidation()
        {
            RuleFor(UserAnswerDto => UserAnswerDto.Answer).NotEmpty();
            RuleFor(UserAnswerDto => UserAnswerDto.QuestionNo).NotEmpty();
            RuleFor(d => d.UserRespId).NotEmpty();

        }
    }

}