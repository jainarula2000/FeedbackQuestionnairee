using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;
using FluentValidation;

namespace FeebackQuestionaireAPI.Mapper.DTOValidation
{
    public class UserValidation:AbstractValidator<UserDto>
    {
        public UserValidation()
        {
            RuleFor(UserDetailsDTO => UserDetailsDTO.UserName);
            
            
        }
    }
    
}