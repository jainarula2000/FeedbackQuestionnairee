using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using FeedBackQuestioneriesApi.Mapper.DTO;
using Microsoft.EntityFrameworkCore;

namespace FeebackQuestionaireAPI.Functionality
{
    public class OptionsService : IOptionsService
    {
        private readonly FeedbackFormDbContext feedbackDbContext;
        public OptionsService(FeedbackFormDbContext _feedbackDbContext)
        {
            feedbackDbContext=_feedbackDbContext;
        }

        async Task<int> IOptionsService.CreateOptions(OptionDetailDTO optionDetailDTO,int quesId)
        {
            var option = new Options(optionDetailDTO,quesId);
            feedbackDbContext.Options.Add(option);
            await feedbackDbContext.SaveChangesAsync();
            return option.OptionId;
        }
        async Task<List<Options>> IOptionsService.GetOptions()
        {
            return await feedbackDbContext.Options.ToListAsync();
        }
    }
    
}