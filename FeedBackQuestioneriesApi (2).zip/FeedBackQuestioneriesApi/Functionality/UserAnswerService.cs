using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using FeedBackQuestioneriesApi.Mapper.DTO;
using Microsoft.EntityFrameworkCore;

namespace FeebackQuestionaireAPI.Functionality
{
    public class UserAnswerService : IUserAnswer
    {
        private readonly FeedbackFormDbContext feedbackDbContext;
        public UserAnswerService(FeedbackFormDbContext _feedbackDbContext)
        {
            feedbackDbContext=_feedbackDbContext;
        }

        async Task<int> IUserAnswer.CreateAnswer(IList<QuestionAnswer> userAnswerDetails, int userId, int formId)
{
        var answers = userAnswerDetails.Select(a => a.Answer).ToArray();
        var userAns = new UserAnswer((List<QuestionAnswer>)userAnswerDetails, userId, formId);
        feedbackDbContext.userAnswers.Add(userAns);
        await feedbackDbContext.SaveChangesAsync();
        return userAns.UserAnsId;
}

        async Task<List<UserAnswer>> IUserAnswer.GetFormAnswersByID(int id)
        {
           List<UserAnswer> forms = new List<UserAnswer>();
           forms = await feedbackDbContext.userAnswers.Where(f => f.UserAnsId == id).ToListAsync();
           return forms;
        }
        // int IUserAnswer.CreateAnswers(UserAnswerDto userAnswerDto)
        // {
        //     int id=0;
        //     UserAnswer userAnswer = new UserAnswer();
        //     userAnswer.Answer=userAnswerDto.Answer;
        //     userAnswer.QuestionNo=userAnswerDto.QuestionNo;
        //     userAnswer.UserRespId=userAnswerDto.UserRespId;
        //     feedbackDbContext.userAnswers.Add(userAnswer);
        //     id=userAnswer.UserAnsId;
        //     return feedbackDbContext.SaveChanges();
        // }

        // int IUserAnswer.DeleteAnswers(int id)
        // {
        //     var Answers = feedbackDbContext.userAnswers.SingleOrDefault(t => t.UserAnsId == id);
        //     if (Answers != null)
        //     {
        //         feedbackDbContext.Remove(Answers);
        //         return feedbackDbContext.SaveChanges();
        //     }
        //     return -1;
        // }

        // object IUserAnswer.FetchAnswers()
        // {
        //  var response = (from a in feedbackDbContext.userAnswers
        //                     join b in feedbackDbContext.UserResponses on a.UserRespId equals b.UserRespId
        //                     select new
        //                     {
        //                         a.Answer,
        //                         a.QuestionNo,
        //                         UserId = b.UserId,
        //                     }).ToList();
        //     return response;
        // }

        // object IUserAnswer.GetAnswers(int id)
        // {
        //     var UserAnswerDto = (from a in feedbackDbContext.userAnswers
        //                             where a.UserAnsId == id
        //                             select new
        //                             {
        //                                 a.Answer,
        //                                 a.QuestionNo,
        //                                 UserRespId=a.UserRespId,
        //                           }).FirstOrDefault();
        //     return UserAnswerDto;

        // }

        // int IUserAnswer. UpdateAnswer(int Id, UserAnswerDto userAnswerDto)
        // {
        //     UserAnswer userAnswer = new UserAnswer();
        //     userAnswer= feedbackDbContext.userAnswers.SingleOrDefault(t=>t.UserAnsId==Id);
        //     if(userAnswer==null)
        //     {
        //         return 0;
        //     }
        //     else
        //     {
        //         Id=0;
        //         userAnswer.Answer=userAnswerDto.Answer;
        //         userAnswer.QuestionNo=userAnswerDto.QuestionNo;
        //         feedbackDbContext.userAnswers.Update(userAnswer);
        //         Id=userAnswer.UserAnsId;
        //         return feedbackDbContext.SaveChanges();

        //     }
        // }


        public async Task<bool> SaveUserResponce(UserFormResponseDto model){

            foreach(var item in model.Responce){
                UserAnswer domain = new UserAnswer{
                    quesId =item.QuestionId,
                    formId = model.FormId,
                    userId = model.UserId,
                    Answer = item.Answer
                };
                feedbackDbContext.userAnswers.Add(domain);
            }
            await feedbackDbContext.SaveChangesAsync();

            return true;
        }
    }
}