using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;

namespace FeebackQuestionaireAPI.Functionality
{
    public interface IUserService
    {
       public Task<int> CreateUsers(UserDto userDto);
    }
}