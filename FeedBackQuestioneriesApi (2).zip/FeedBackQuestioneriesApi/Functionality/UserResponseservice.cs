using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using Microsoft.EntityFrameworkCore;

namespace FeebackQuestionaireAPI.Functionality
{
    public class UserResponseservice : IUserResponseService
    {
         private readonly FeedbackFormDbContext feedbackDbContext;
        public UserResponseservice(FeedbackFormDbContext _feedbackDbContext)
        {
            feedbackDbContext=_feedbackDbContext;
        }

        async Task<int> IUserResponseService.CreateResponse(UserResponseDto userResponseDto)
        {
            var questionResponse = new UserResponse(userResponseDto);
            feedbackDbContext.UserResponses.Add(questionResponse);
            await feedbackDbContext.SaveChangesAsync();
            return questionResponse.UserRespId;
        }
        // int IUserResponseService.funcAddRespose(UserResponseDto userResponseDto)
        // {
        //     int id=0;
        //     UserResponse userResponse = new UserResponse();
        //     {
        //         //userResponse.QuesId=userResponseDto.QuestId;
        //         userResponse.UserId=userResponseDto.UserId;
        //         feedbackDbContext.UserResponses.Add(userResponse);
        //         id = userResponse.UserRespId;
        //         return feedbackDbContext.SaveChanges();

        //     }

        // }

        // async Task<List<UserResponse>> IUserResponseService.GetUserResponses()
        // {
        //     var UserResponseList=await feedbackDbContext.UserResponses.Include(d=>d.Users).ToListAsync();
        //     return UserResponseList;
        // }
    }
}