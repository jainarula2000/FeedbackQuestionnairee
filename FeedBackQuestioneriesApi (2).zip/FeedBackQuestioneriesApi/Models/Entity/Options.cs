using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeedBackQuestioneriesApi.Mapper.DTO;

namespace FeebackQuestionaireAPI.Models.Entity
{
    public class Options
    {

        public Options(OptionDetailDTO optionsDTO, int quesId)
        {
            Option = optionsDTO.Option;
            QuestId = quesId;

        }
        public Options()
        {

        }
        [Key]
        public int OptionId { get; set; }
        [ForeignKey("QuestId")]
        public int QuestId { get; set; } //foreign key
        public virtual Question Questions { get; set; }
        public string Option { get; set; }

        public Options(string option, int quesId)
        {
            QuestId = quesId;
            Option = option;
        }
    }
}