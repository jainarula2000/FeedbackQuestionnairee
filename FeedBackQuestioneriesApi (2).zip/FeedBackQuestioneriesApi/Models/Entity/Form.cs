using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeedBackQuestioneriesApi.Mapper.DTO;
using Microsoft.EntityFrameworkCore;

namespace FeebackQuestionaireAPI.Models.Entity
{
    public class Form
    {
        
        public int FormId { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string Link { get; set; }
        public int Submissions { get; set; }
        public DateTime PublishedDate { get; set; }
        public Status FormStatus { get; set; }
        public DateTime ClosedDate { get; set; }

        public bool IsDeleted { get; set; }


        //Navigation Property
        public ICollection<Question> Questions { get; set; }
        public enum Status
        {
            Published = 1, Drafted = 2, Losed = 3
        }
        public Form()
        {

        }

        public Form(FormDtO formDtO)
        {

            Title = formDtO.Title;
            Description = formDtO.Description;
            FormStatus = formDtO.Status;
            PublishedDate = new DateTime();
            ClosedDate = new DateTime();
            Link = "http://localhost:5000/Form/GetForm";
            FormStatus = formDtO.Status;
            Submissions = formDtO.Submissions;
            IsDeleted = formDtO.IsDeleted;

            // Questions = GetAllTypeofQuestion(formDtO);

        }
        public Form(FormDetailsDTO formDetailsDTO)
        {
            Title = formDetailsDTO.Title;
            Description = formDetailsDTO.Description;
            PublishedDate = DateTime.UtcNow;
            ClosedDate = DateTime.UtcNow;
            Link = "http://localhost:5000/Form/GetForm";
            FormStatus = (Status)formDetailsDTO.Status;
            Submissions = formDetailsDTO.Submissions;
            IsDeleted = false;
            Questions = GetAllQuestions(formDetailsDTO.questionDetailDTO.ToList(), FormId);

        }
        public List<Question> GetAllQuestions(List<QuestionDetailDTO> questionDetailDTO, int FormId)
        {
            List<Question> questions = new List<Question>();
            foreach (var question in questionDetailDTO)
            {
                questions.Add(new Question(question, FormId));
            }
            return questions;
        }

    }
}