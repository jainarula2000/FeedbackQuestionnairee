using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeedBackQuestioneriesApi.Mapper.DTO;
using FeedBackQuestioneriesApi.Models.Entity;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
namespace FeebackQuestionaireAPI.Models.Entity
{
    public class Question
    {
        [Key]

        public int QuestId { get; set; }
        public QuestionType TypeId { get; set; }
        public string QuestionName { get; set; }

        [ForeignKey("FormId")]
        public int FormId { get; set; }//fk
        public virtual Form Forms { get; set; } //Navigation Property for Form.
        public IList<Options> Options { get; set; } //One Question have multiple option for that we are using Navigation property for making relation between them.
        public virtual UserAnswer ans { get; set; }
        
        public int userId { get; set; }
        public Question()
        {

        }
        public Question(QuestionsDTO questionsDTO)
        {

            QuestionName = questionsDTO.QuestionName;
            FormId = questionsDTO.FormId;
            TypeId = (QuestionType)questionsDTO.TypeId;

            // Questions = GetAllTypeofQuestion(formDtO);

        }
        public Question(QuestionDetailDTO questionDetailDTO, int formId)
        {
            QuestionName = questionDetailDTO.QuestionName;
            FormId = formId;
            TypeId = (QuestionType)questionDetailDTO.TypeId;
            Options = GetAlloptions(questionDetailDTO.optionDetailDTO, QuestId);
            
        }
        public List<Options> GetAlloptions(IList<OptionDetailDTO> optionDetailDTO, int quesId)
        {
            List<Options> options = new List<Options>();
            foreach (var option in optionDetailDTO)
            {
                options.Add(new Options(option.Option, quesId));
            }
            return options;
        }
        public List<UserAnswer> GetAllAnswers(IList<QuestionAnswer> userAnswerDetails, int userId, int formId)
        {
            List<UserAnswer> userAnswers = new List<UserAnswer>();
            foreach (var answer in userAnswerDetails)
            {
                var questionAnswer = new QuestionAnswer
                {
                    questId = answer.questId,
                    Answer = answer.Answer
                };

                userAnswers.Add(new UserAnswer(new List<QuestionAnswer> { questionAnswer }, userId, formId));
            }
            return userAnswers;
        }
    }

    public enum QuestionType
    {
        SingleChoice = 1,
        MultiChoice = 2,
        Rating = 3,
        Ranking = 4,
        SingleLineAnswer = 5,
        MultiLineAnswer = 6
    }


}


