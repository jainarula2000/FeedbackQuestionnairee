using System.Data;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeedBackQuestioneriesApi.Mapper.DTO;

namespace FeebackQuestionaireAPI.Models.Entity
{
    public class UserAnswer
    {
        [Key]
        public int UserAnsId { get; set; } //pk
        public string Answer { get; set; }
        [ForeignKey("quesId")]
        public int quesId { get; set; }
        [ForeignKey("userId")]
        public int userId { get; set; }
        [ForeignKey("formId")]
        public int formId { get; set; }
        public virtual UserAnswer ans { get; set; }
        //cascading
        public List<QuestionAnswer> QuestionAnswers { get; set; }

        
        
        

    public UserAnswer(List<QuestionAnswer> questionAnswers, int userid, int formid)
    {
        QuestionAnswers = questionAnswers;
        userId = userid;
        formId = formid;
    }

        public UserAnswer()
        {
            QuestionAnswers = new List<QuestionAnswer>();
        }


    

}

public class QuestionAnswer
{
    [Key]
    public int questId{get;set;}
    public string Answer{get;set;}
}
}
