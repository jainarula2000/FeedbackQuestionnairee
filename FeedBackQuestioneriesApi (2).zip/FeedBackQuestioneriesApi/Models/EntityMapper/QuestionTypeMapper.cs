using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Models.Entity;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace FeebackQuestionaireAPI.Models.EntityMapper
{
    public class QuestionTypeMapper
    {
        //  public QuestionTypeMapper(EntityTypeBuilder<QuestionTypes> entityTypeBuilder)
        // {
        //     entityTypeBuilder.HasKey(e=>e.QuesTypeId);
        //     entityTypeBuilder.Property(e=>e.Type).IsRequired();
        //     //entityTypeBuilder.HasMany(e=>e.Question).WithMany(e=>e.questionTypes).HasForeignKey<Question>(t=>t.QuestionTypeId);
        // }
    }
}