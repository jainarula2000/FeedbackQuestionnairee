﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace FeedBackQuestioneriesApi.Migrations
{
    /// <inheritdoc />
    public partial class p2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Forms",
                columns: table => new
                {
                    FormId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Title = table.Column<string>(type: "text", nullable: false),
                    Description = table.Column<string>(type: "text", nullable: false),
                    Link = table.Column<string>(type: "text", nullable: false),
                    Submissions = table.Column<int>(type: "integer", nullable: false),
                    PublishedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    FormStatus = table.Column<int>(type: "integer", nullable: false),
                    ClosedDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    IsDeleted = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Forms", x => x.FormId);
                });

            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    UserId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    UserName = table.Column<string>(type: "text", nullable: true),
                    Email = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.UserId);
                });

            migrationBuilder.CreateTable(
                name: "UserResponses",
                columns: table => new
                {
                    UserRespId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    formId = table.Column<int>(type: "integer", nullable: false),
                    UserId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_UserResponses", x => x.UserRespId);
                    table.ForeignKey(
                        name: "FK_UserResponses_Forms_formId",
                        column: x => x.formId,
                        principalTable: "Forms",
                        principalColumn: "FormId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_UserResponses_Users_UserId",
                        column: x => x.UserId,
                        principalTable: "Users",
                        principalColumn: "UserId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "userAnswers",
                columns: table => new
                {
                    UserAnsId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Answer = table.Column<string>(type: "text", nullable: true),
                    quesId = table.Column<int>(type: "integer", nullable: false),
                    userId = table.Column<int>(type: "integer", nullable: false),
                    formId = table.Column<int>(type: "integer", nullable: false),
                    // ansUserAnsId = table.Column<int>(type: "integer", nullable: true),
                    // UserResponseUserRespId = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_userAnswers", x => x.UserAnsId);
                    // table.ForeignKey(
                    //     name: "FK_userAnswers_UserResponses_UserResponseUserRespId",
                    //     column: x => x.UserResponseUserRespId,
                    //     principalTable: "UserResponses",
                    //     principalColumn: "UserRespId");
                //     table.ForeignKey(
                //         name: "FK_userAnswers_userAnswers_ansUserAnsId",
                //         column: x => x.ansUserAnsId,
                //         principalTable: "userAnswers",
                //         principalColumn: "UserAnsId");
                 });

            migrationBuilder.CreateTable(
                name: "QuestionAnswer",
                columns: table => new
                {
                    questId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Answer = table.Column<string>(type: "text", nullable: true),
                    UserAnswerUserAnsId = table.Column<int>(type: "integer", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_QuestionAnswer", x => x.questId);
                    table.ForeignKey(
                        name: "FK_QuestionAnswer_userAnswers_UserAnswerUserAnsId",
                        column: x => x.UserAnswerUserAnsId,
                        principalTable: "userAnswers",
                        principalColumn: "UserAnsId");
                });

            migrationBuilder.CreateTable(
                name: "Questions",
                columns: table => new
                {
                    QuestId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    TypeId = table.Column<int>(type: "integer", nullable: false),
                    QuestionName = table.Column<string>(type: "text", nullable: false),
                    FormId = table.Column<int>(type: "integer", nullable: false),
                   // ansUserAnsId = table.Column<int>(type: "integer", nullable: true),
                    userId = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Questions", x => x.QuestId);
                    table.ForeignKey(
                        name: "FK_Questions_Forms_FormId",
                        column: x => x.FormId,
                        principalTable: "Forms",
                        principalColumn: "FormId",
                        onDelete: ReferentialAction.Cascade);
                    // table.ForeignKey(
                    //     name: "FK_Questions_userAnswers_ansUserAnsId",
                    //     column: x => x.ansUserAnsId,
                    //     principalTable: "userAnswers",
                    //     principalColumn: "UserAnsId");
                });

            migrationBuilder.CreateTable(
                name: "Options",
                columns: table => new
                {
                    OptionId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    QuestId = table.Column<int>(type: "integer", nullable: false),
                    QuestionsQuestId = table.Column<int>(type: "integer", nullable: true),
                    Option = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Options", x => x.OptionId);
                    table.ForeignKey(
                        name: "FK_Options_Questions_QuestionsQuestId",
                        column: x => x.QuestionsQuestId,
                        principalTable: "Questions",
                        principalColumn: "QuestId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Options_QuestionsQuestId",
                table: "Options",
                column: "QuestionsQuestId");

            migrationBuilder.CreateIndex(
                name: "IX_QuestionAnswer_UserAnswerUserAnsId",
                table: "QuestionAnswer",
                column: "UserAnswerUserAnsId");

            // migrationBuilder.CreateIndex(
            //     name: "IX_Questions_ansUserAnsId",
            //     table: "Questions",
            //     column: "ansUserAnsId");

            migrationBuilder.CreateIndex(
                name: "IX_Questions_FormId",
                table: "Questions",
                column: "FormId");

            // migrationBuilder.CreateIndex(
            //     name: "IX_userAnswers_ansUserAnsId",
            //     table: "userAnswers",
            //     column: "ansUserAnsId");

            migrationBuilder.CreateIndex(
                name: "IX_userAnswers_UserResponseUserRespId",
                table: "userAnswers",
                column: "UserResponseUserRespId");

            migrationBuilder.CreateIndex(
                name: "IX_UserResponses_formId",
                table: "UserResponses",
                column: "formId");

            migrationBuilder.CreateIndex(
                name: "IX_UserResponses_UserId",
                table: "UserResponses",
                column: "UserId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Options");

            migrationBuilder.DropTable(
                name: "QuestionAnswer");

            migrationBuilder.DropTable(
                name: "Questions");

            migrationBuilder.DropTable(
                name: "userAnswers");

            migrationBuilder.DropTable(
                name: "UserResponses");

            migrationBuilder.DropTable(
                name: "Forms");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
