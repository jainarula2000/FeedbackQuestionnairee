using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Functionality;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using FeedBackQuestioneriesApi.Mapper.DTO;
using FluentValidation;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Mvc;

namespace FeebackQuestionaireAPI.Controllers
{
    [ApiController]
    [Route("[controller]")]
    [EnableCors("AllowOrign")]
    public class FormController : ControllerBase
    {
        private readonly IFormService formService;

        private readonly IValidator<FormDtO> validator;
        public FormController(IFormService _formService, IValidator<FormDtO> _validator)
        {

            formService = _formService;
            validator = _validator;
        }


        [HttpPost("create")]
        public async Task<ActionResult<int>> funcreateFormAsync(FormDetailsDTO formDetailsDTO)
        {
            var formId = await formService.CreateForm(formDetailsDTO);
            return Ok(formId);
        }

        [HttpGet("get")]
        public async Task<IActionResult> FetchQuestions()
        {
            return Ok(await formService.GetForm());
        }
        [HttpDelete("delete")]
        public IActionResult Deleteinvoice(int id)
        {
            return Ok(formService.DeleteForms(id));
        }
      //  [HttpPut]
      //  [Route(("update"))]
      //  public IActionResult UpdateForms(int Id, FormDetailsDTO formDto)
     //   {
     //  /     var updatedForm = formService.UpdateForm(Id, formDto);
        //    if (updatedForm == null)
            //{
         //       return NotFound();
        //    }

       //     return Ok(updatedForm);
     //   }

        [HttpGet("getFormById/{id}")]
        public async Task<ActionResult<Form>> GetFormById(int id)
        {
            var form = await formService.GetFormByid(id);

            if (form == null)
            {
                return NotFound();
            }

            return Ok(form);
        }
        [HttpPost("NewForm")]
        public async Task<IActionResult> GetFormByName(FormDetailsDTO formDetailsDTO)
        {

            return Ok(await formService.SaveForm(formDetailsDTO));
        }
        [HttpPut]
        [Route(("updateForm"))]
        public IActionResult UpdateFormData(int id, FormDetailsDTO formDetailsDTO)
        {
            int result = formService.EditForm(id, formDetailsDTO);

            if (result != -1)
            {
                return Ok();
            }

            return NotFound();

        }

    }
}