using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Functionality;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;

namespace FeebackQuestionaireAPI.Controllers
{
     [ApiController]
    [Route("[controller]")]
    public class UserController:ControllerBase
    {
        private readonly IUserService UserService;
        private readonly IValidator<UserDto> validator;
        
        public UserController(IUserService _UserService,IValidator<UserDto> _validator)
        {
            UserService=_UserService;
            validator=_validator;
        }
         [HttpPost("create")]
        public async Task<ActionResult<int>> funcreateFormAsync(UserDto userDto)
         {
            var userId = await UserService.CreateUsers(userDto);
            return Ok(userId);
        }
       

    }  
}