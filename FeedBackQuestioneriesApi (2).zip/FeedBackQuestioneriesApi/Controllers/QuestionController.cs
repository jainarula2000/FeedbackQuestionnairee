using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Database;
using FeebackQuestionaireAPI.Functionality;
using FeebackQuestionaireAPI.Mapper.DTO;
using FeebackQuestionaireAPI.Models.Entity;
using FeedBackQuestioneriesApi.Mapper.DTO;
using FluentValidation;
using Microsoft.AspNetCore.Mvc;

namespace FeebackQuestionaireAPI.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class QuestionController : ControllerBase
    {
         private readonly IQuestionService QuestionService;
         private readonly IOptionsService optionsService;
        private readonly IValidator<QuestionsDTO> validator;
        public QuestionController(IQuestionService _QuestionService,IValidator<QuestionsDTO> _validator,IOptionsService _optionsService)
        {
            optionsService=_optionsService;
            QuestionService=_QuestionService;
            validator=_validator;
        }
        
         [HttpPost("crete")]
        public async Task<ActionResult<int>> funcreateQuestionsc(QuestionsDTO questionsDTO)
         {
            var QuesId = await QuestionService.CreateQuestions(questionsDTO);
            return Ok(QuesId);
        }
        [HttpGet]
        public async Task<IActionResult> FetchQuestions()
        {
            return Ok(await QuestionService.GetQuestion());
        }
        [HttpDelete("{id}")]
        public IActionResult DeleteQuestion(int id)
        {
            return Ok(QuestionService.DeleteQuestion(id));
        }
        [HttpPut]
        [Route(("Update"))]
        public IActionResult UpdateForms(QuestionsDTO question)
        {
            return Ok(QuestionService.UpdateForms(question));
        }
         [HttpPost("Option/Create")]
        public async Task<ActionResult<int>> funcreateOption(OptionDetailDTO optionsDTO,int quesId)
         {
           var OptionId = await optionsService.CreateOptions(optionsDTO,quesId);
            return Ok(OptionId);
        }
        [HttpGet("Option/Fetch")]
        public async Task<IActionResult> FetchOptions()
        {
            return Ok(await optionsService.GetOptions());
        }
       
    }
}