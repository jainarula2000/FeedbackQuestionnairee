using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FeebackQuestionaireAPI.Models.Entity;
using FeebackQuestionaireAPI.Models.EntityMapper;
using FeedBackQuestioneriesApi.Models.Entity;
using Microsoft.EntityFrameworkCore;

namespace FeebackQuestionaireAPI.Database
{
    public class FeedbackFormDbContext : DbContext
    {
        //Constructor Chaining.
        public FeedbackFormDbContext(DbContextOptions options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)// //Using FluentApi for making constraints and required fields.
        {
            new FormMapper(modelBuilder.Entity<Form>());
            new QuestionMapper(modelBuilder.Entity<Question>());


        }
        //Creating Table in Database by using DbSet<>.
        public DbSet<Form> Forms { get; set; }
        public DbSet<Question> Questions { get; set; }
        public DbSet<Options> Options { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<UserResponse> UserResponses { get; set; }
        public DbSet<UserAnswer> userAnswers { get; set; }
       

    }

}